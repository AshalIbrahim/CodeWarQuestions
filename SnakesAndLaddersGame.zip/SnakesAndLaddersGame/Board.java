package CodeWarsQuestions.SnakesAndLaddersGame;
import java.util.HashMap;
import java.util.Map;
import java.util.*;

public class Board {
    HashMap<Integer,Integer> LadderMapping;
    HashMap<Integer,Integer> SnakeMapping;

    public Board() {
        LadderMapping=new HashMap<>();
        SnakeMapping=new HashMap<>();
        setLadderMapping();
    }

    public void setLadderMapping(){
        this.LadderMapping.put(2,38);
        this.LadderMapping.put(7,14);
        this.LadderMapping.put(8,31);
        this.LadderMapping.put(15,26);
        this.LadderMapping.put(21,42);
        this.LadderMapping.put(28,84);
        this.LadderMapping.put(36,44);
        this.LadderMapping.put(51,67);
        this.LadderMapping.put(71,91);
        this.LadderMapping.put(78,98);
    }
    public void setSnakeMapping(){
        this.SnakeMapping.put(99,80);
        this.SnakeMapping.put(95,75);
        this.SnakeMapping.put(92,88);

    }

    public static void main(String[] args) {
        Board b=new Board();

        int sumOfDie=15;
        if(b.LadderMapping.containsKey(sumOfDie)){
            sumOfDie=b.LadderMapping.get(sumOfDie);
        }
        System.out.println("New Position of player one is: "+sumOfDie);
    }
}
