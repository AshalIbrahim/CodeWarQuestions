package CodeWarsQuestions.SnakesAndLaddersGame;

public class Player {
   public String name;
    private int boardPosition;

    public Player(String name) {
        this.name = name;
        boardPosition=0;
    }

    public void setBoardPosition(int boardPosition) {
        this.boardPosition = boardPosition;
    }

    public int getBoardPosition() {
        return boardPosition;
    }

    public String getName() {
        return name;
    }

}
