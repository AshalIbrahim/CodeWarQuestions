package CodeWarsQuestions.SnakesAndLaddersGame;

import java.util.Scanner;

public class Game {
    static Player p1;
    static Player p2;
    boolean Player1Turn;
    Board b;
    public String play(Player p,int die1, int die2) {
        if(p.getBoardPosition()==100) {return p.getName()+" has won";}
        else{
        int sumOfDie=die1+die2;
        System.out.println(p.getName() +" is on board position: "+p.getBoardPosition());
        System.out.println("Die 1: "+die1+", Die 2: "+die2);
        if(sumOfDie+p.getBoardPosition()==100){
            p.setBoardPosition(sumOfDie+p.getBoardPosition());
            return p.getName()+" has won";
        }else if(sumOfDie+p.getBoardPosition()>100){
            sumOfDie=p.getBoardPosition()+sumOfDie;
            p.setBoardPosition( 100-(sumOfDie-100) );
            return p.getName()+" is on tile: "+p.getBoardPosition()+"\n";
        }
        if(b.LadderMapping.containsKey(sumOfDie+p.getBoardPosition())){
            System.out.println("Ladder Boost!");
            p.setBoardPosition(b.LadderMapping.get(sumOfDie+p.getBoardPosition()));
        }else{
            int newPosition=sumOfDie+p.getBoardPosition();
            p.setBoardPosition(newPosition);
        }

        return p.getName()+" is on tile: "+p.getBoardPosition()+"\n";
        }
    }

    public int dieValue(){
        return (int)(Math.random() * 6) + 1;
    }
    public Game() {
        Player1Turn = true;
        b=new Board();
        p1=new Player("Player 1");
        p2=new Player("Player 2");
    }

    public static void main(String[] args) {

        Game g=new Game();
        while(p1.getBoardPosition()!=100 || p2.getBoardPosition()!=100){
            if(g.Player1Turn){
                if(p1.getBoardPosition()==100)break;
                int die1=g.dieValue();
                int die2=g.dieValue();
                System.out.println(g.play(p1,g.dieValue(),g.dieValue()));
                if(die2==die1){g.Player1Turn=true;}
                else g.Player1Turn=false;
            }else{
                if(p2.getBoardPosition()==100)break;
                int die1=g.dieValue();
                int die2=g.dieValue();
                System.out.println(g.play(p2,g.dieValue(),g.dieValue()));
                if(die2==die1){g.Player1Turn=false;}
                else g.Player1Turn=true;
            }
        }
    }
}
